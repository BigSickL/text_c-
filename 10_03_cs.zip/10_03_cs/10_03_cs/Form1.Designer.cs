﻿namespace _10_03_cs
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Soubor = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.otevřítToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otevřítToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.barvaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.btn_q = new System.Windows.Forms.Button();
            this.btn_w = new System.Windows.Forms.Button();
            this.btn_e = new System.Windows.Forms.Button();
            this.btn_r = new System.Windows.Forms.Button();
            this.btn_t = new System.Windows.Forms.Button();
            this.btn_z = new System.Windows.Forms.Button();
            this.btn_zv_1 = new System.Windows.Forms.Button();
            this.btn_zv_0 = new System.Windows.Forms.Button();
            this.btn_p = new System.Windows.Forms.Button();
            this.btn_o = new System.Windows.Forms.Button();
            this.btn_i = new System.Windows.Forms.Button();
            this.btn_u = new System.Windows.Forms.Button();
            this.btn_zv_4 = new System.Windows.Forms.Button();
            this.btn_zv_3 = new System.Windows.Forms.Button();
            this.btn_zv_2 = new System.Windows.Forms.Button();
            this.btn_l = new System.Windows.Forms.Button();
            this.btn_k = new System.Windows.Forms.Button();
            this.btn_j = new System.Windows.Forms.Button();
            this.btn_h = new System.Windows.Forms.Button();
            this.btn_g = new System.Windows.Forms.Button();
            this.btn_f = new System.Windows.Forms.Button();
            this.btn_d = new System.Windows.Forms.Button();
            this.btn_s = new System.Windows.Forms.Button();
            this.btn_a = new System.Windows.Forms.Button();
            this.btn_rovnase = new System.Windows.Forms.Button();
            this.btn_minus = new System.Windows.Forms.Button();
            this.btn_0 = new System.Windows.Forms.Button();
            this.btn_9 = new System.Windows.Forms.Button();
            this.btn_8 = new System.Windows.Forms.Button();
            this.btn_7 = new System.Windows.Forms.Button();
            this.btn_6 = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.btn_3 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_1 = new System.Windows.Forms.Button();
            this.btn_strednik = new System.Windows.Forms.Button();
            this.btn_tab = new System.Windows.Forms.Button();
            this.btn_shift_0 = new System.Windows.Forms.Button();
            this.btn_capslock = new System.Windows.Forms.Button();
            this.btn_shift_1 = new System.Windows.Forms.Button();
            this.btn_zv_7 = new System.Windows.Forms.Button();
            this.btn_zv_6 = new System.Windows.Forms.Button();
            this.btn_zv_5 = new System.Windows.Forms.Button();
            this.btn_m = new System.Windows.Forms.Button();
            this.btn_n = new System.Windows.Forms.Button();
            this.btn_b = new System.Windows.Forms.Button();
            this.btn_v = new System.Windows.Forms.Button();
            this.btn_c = new System.Windows.Forms.Button();
            this.btn_x = new System.Windows.Forms.Button();
            this.btn_y = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.btn_zpet = new System.Windows.Forms.Button();
            this.btn_reset_0 = new System.Windows.Forms.Button();
            this.btn_eng_0 = new System.Windows.Forms.Button();
            this.btn_alt_0 = new System.Windows.Forms.Button();
            this.btn_mezernik = new System.Windows.Forms.Button();
            this.btn_alt_1 = new System.Windows.Forms.Button();
            this.btn_eng_1 = new System.Windows.Forms.Button();
            this.btn_reset_1 = new System.Windows.Forms.Button();
            this.btn_win_lock = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.btn_num = new System.Windows.Forms.Button();
            this.btn_num_deleno = new System.Windows.Forms.Button();
            this.bnt_num_krat = new System.Windows.Forms.Button();
            this.btn_num_minus = new System.Windows.Forms.Button();
            this.btn_num_plus = new System.Windows.Forms.Button();
            this.btn_num_9 = new System.Windows.Forms.Button();
            this.btn_num_8 = new System.Windows.Forms.Button();
            this.btn_num_7 = new System.Windows.Forms.Button();
            this.btn_num_6 = new System.Windows.Forms.Button();
            this.btn_num_3 = new System.Windows.Forms.Button();
            this.btn_num_carka = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.btn_num_5 = new System.Windows.Forms.Button();
            this.btn_num_2 = new System.Windows.Forms.Button();
            this.btn_num_4 = new System.Windows.Forms.Button();
            this.btn_num_1 = new System.Windows.Forms.Button();
            this.btn_num_0 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Soubor.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 27);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(789, 355);
            this.textBox1.TabIndex = 0;
            this.textBox1.UseWaitCursor = true;
            // 
            // Soubor
            // 
            this.Soubor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.otevřítToolStripMenuItem});
            this.Soubor.Location = new System.Drawing.Point(0, 0);
            this.Soubor.Name = "Soubor";
            this.Soubor.Size = new System.Drawing.Size(848, 24);
            this.Soubor.TabIndex = 1;
            this.Soubor.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(57, 20);
            this.toolStripMenuItem1.Text = "Soubor";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(110, 22);
            this.toolStripMenuItem2.Text = "Otevřít";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.otevřítToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(110, 22);
            this.toolStripMenuItem3.Text = "Uložit";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.uložitToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(110, 22);
            this.toolStripMenuItem4.Text = "Konec";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.konecToolStripMenuItem_Click);
            // 
            // otevřítToolStripMenuItem
            // 
            this.otevřítToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.otevřítToolStripMenuItem1,
            this.barvaToolStripMenuItem});
            this.otevřítToolStripMenuItem.Name = "otevřítToolStripMenuItem";
            this.otevřítToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.otevřítToolStripMenuItem.Text = "Font";
            // 
            // otevřítToolStripMenuItem1
            // 
            this.otevřítToolStripMenuItem1.Name = "otevřítToolStripMenuItem1";
            this.otevřítToolStripMenuItem1.Size = new System.Drawing.Size(103, 22);
            this.otevřítToolStripMenuItem1.Text = "Font";
            this.otevřítToolStripMenuItem1.Click += new System.EventHandler(this.pismoToolStripMenuItem_Click);
            // 
            // barvaToolStripMenuItem
            // 
            this.barvaToolStripMenuItem.Name = "barvaToolStripMenuItem";
            this.barvaToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.barvaToolStripMenuItem.Text = "barva";
            this.barvaToolStripMenuItem.Click += new System.EventHandler(this.barvaToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btn_q
            // 
            this.btn_q.Location = new System.Drawing.Point(66, 430);
            this.btn_q.Name = "btn_q";
            this.btn_q.Size = new System.Drawing.Size(32, 23);
            this.btn_q.TabIndex = 2;
            this.btn_q.Text = "q";
            this.btn_q.UseVisualStyleBackColor = true;
            this.btn_q.Click += new System.EventHandler(this.btn_q_Click);
            // 
            // btn_w
            // 
            this.btn_w.Location = new System.Drawing.Point(104, 430);
            this.btn_w.Name = "btn_w";
            this.btn_w.Size = new System.Drawing.Size(32, 23);
            this.btn_w.TabIndex = 3;
            this.btn_w.Text = "w";
            this.btn_w.UseVisualStyleBackColor = true;
            this.btn_w.Click += new System.EventHandler(this.btn_w_Click);
            // 
            // btn_e
            // 
            this.btn_e.Location = new System.Drawing.Point(142, 430);
            this.btn_e.Name = "btn_e";
            this.btn_e.Size = new System.Drawing.Size(32, 23);
            this.btn_e.TabIndex = 4;
            this.btn_e.Text = "e";
            this.btn_e.UseVisualStyleBackColor = true;
            this.btn_e.Click += new System.EventHandler(this.btn_e_Click);
            // 
            // btn_r
            // 
            this.btn_r.Location = new System.Drawing.Point(180, 430);
            this.btn_r.Name = "btn_r";
            this.btn_r.Size = new System.Drawing.Size(32, 23);
            this.btn_r.TabIndex = 5;
            this.btn_r.Text = "r";
            this.btn_r.UseVisualStyleBackColor = true;
            this.btn_r.Click += new System.EventHandler(this.btn_r_Click);
            // 
            // btn_t
            // 
            this.btn_t.Location = new System.Drawing.Point(218, 430);
            this.btn_t.Name = "btn_t";
            this.btn_t.Size = new System.Drawing.Size(32, 23);
            this.btn_t.TabIndex = 6;
            this.btn_t.Text = "t";
            this.btn_t.UseVisualStyleBackColor = true;
            this.btn_t.Click += new System.EventHandler(this.btn_t_Click);
            // 
            // btn_z
            // 
            this.btn_z.Location = new System.Drawing.Point(256, 430);
            this.btn_z.Name = "btn_z";
            this.btn_z.Size = new System.Drawing.Size(32, 23);
            this.btn_z.TabIndex = 7;
            this.btn_z.Text = "y";
            this.btn_z.UseVisualStyleBackColor = true;
            this.btn_z.Click += new System.EventHandler(this.btn_z_Click);
            // 
            // btn_zv_1
            // 
            this.btn_zv_1.Location = new System.Drawing.Point(484, 430);
            this.btn_zv_1.Name = "btn_zv_1";
            this.btn_zv_1.Size = new System.Drawing.Size(46, 23);
            this.btn_zv_1.TabIndex = 13;
            this.btn_zv_1.Text = "]";
            this.btn_zv_1.UseVisualStyleBackColor = true;
            this.btn_zv_1.Click += new System.EventHandler(this.btn_zv_1_Click);
            // 
            // btn_zv_0
            // 
            this.btn_zv_0.Location = new System.Drawing.Point(446, 430);
            this.btn_zv_0.Name = "btn_zv_0";
            this.btn_zv_0.Size = new System.Drawing.Size(32, 23);
            this.btn_zv_0.TabIndex = 12;
            this.btn_zv_0.Text = "[";
            this.btn_zv_0.UseVisualStyleBackColor = true;
            this.btn_zv_0.Click += new System.EventHandler(this.btn_zv_0_Click);
            // 
            // btn_p
            // 
            this.btn_p.Location = new System.Drawing.Point(408, 430);
            this.btn_p.Name = "btn_p";
            this.btn_p.Size = new System.Drawing.Size(32, 23);
            this.btn_p.TabIndex = 11;
            this.btn_p.Text = "p";
            this.btn_p.UseVisualStyleBackColor = true;
            this.btn_p.Click += new System.EventHandler(this.btn_p_Click);
            // 
            // btn_o
            // 
            this.btn_o.Location = new System.Drawing.Point(370, 430);
            this.btn_o.Name = "btn_o";
            this.btn_o.Size = new System.Drawing.Size(32, 23);
            this.btn_o.TabIndex = 10;
            this.btn_o.Text = "o";
            this.btn_o.UseVisualStyleBackColor = true;
            this.btn_o.Click += new System.EventHandler(this.btn_o_Click);
            // 
            // btn_i
            // 
            this.btn_i.Location = new System.Drawing.Point(332, 430);
            this.btn_i.Name = "btn_i";
            this.btn_i.Size = new System.Drawing.Size(32, 23);
            this.btn_i.TabIndex = 9;
            this.btn_i.Text = "i";
            this.btn_i.UseVisualStyleBackColor = true;
            this.btn_i.Click += new System.EventHandler(this.btn_i_Click);
            // 
            // btn_u
            // 
            this.btn_u.Location = new System.Drawing.Point(294, 430);
            this.btn_u.Name = "btn_u";
            this.btn_u.Size = new System.Drawing.Size(32, 23);
            this.btn_u.TabIndex = 8;
            this.btn_u.Text = "u";
            this.btn_u.UseVisualStyleBackColor = true;
            this.btn_u.Click += new System.EventHandler(this.btn_u_Click);
            // 
            // btn_zv_4
            // 
            this.btn_zv_4.Location = new System.Drawing.Point(498, 459);
            this.btn_zv_4.Name = "btn_zv_4";
            this.btn_zv_4.Size = new System.Drawing.Size(32, 23);
            this.btn_zv_4.TabIndex = 25;
            this.btn_zv_4.Text = "\\";
            this.btn_zv_4.UseVisualStyleBackColor = true;
            this.btn_zv_4.Click += new System.EventHandler(this.btn_zv_4_Click);
            // 
            // btn_zv_3
            // 
            this.btn_zv_3.Location = new System.Drawing.Point(460, 459);
            this.btn_zv_3.Name = "btn_zv_3";
            this.btn_zv_3.Size = new System.Drawing.Size(32, 23);
            this.btn_zv_3.TabIndex = 24;
            this.btn_zv_3.Text = "\'";
            this.btn_zv_3.UseVisualStyleBackColor = true;
            this.btn_zv_3.Click += new System.EventHandler(this.btn_zv_3_Click);
            // 
            // btn_zv_2
            // 
            this.btn_zv_2.Location = new System.Drawing.Point(422, 459);
            this.btn_zv_2.Name = "btn_zv_2";
            this.btn_zv_2.Size = new System.Drawing.Size(32, 23);
            this.btn_zv_2.TabIndex = 23;
            this.btn_zv_2.Text = ";";
            this.btn_zv_2.UseVisualStyleBackColor = true;
            this.btn_zv_2.Click += new System.EventHandler(this.btn_zv_2_Click);
            // 
            // btn_l
            // 
            this.btn_l.Location = new System.Drawing.Point(384, 459);
            this.btn_l.Name = "btn_l";
            this.btn_l.Size = new System.Drawing.Size(32, 23);
            this.btn_l.TabIndex = 22;
            this.btn_l.Text = "l";
            this.btn_l.UseVisualStyleBackColor = true;
            this.btn_l.Click += new System.EventHandler(this.btn_l_Click);
            // 
            // btn_k
            // 
            this.btn_k.Location = new System.Drawing.Point(346, 459);
            this.btn_k.Name = "btn_k";
            this.btn_k.Size = new System.Drawing.Size(32, 23);
            this.btn_k.TabIndex = 21;
            this.btn_k.Text = "k";
            this.btn_k.UseVisualStyleBackColor = true;
            this.btn_k.Click += new System.EventHandler(this.btn_k_Click);
            // 
            // btn_j
            // 
            this.btn_j.Location = new System.Drawing.Point(308, 459);
            this.btn_j.Name = "btn_j";
            this.btn_j.Size = new System.Drawing.Size(32, 23);
            this.btn_j.TabIndex = 20;
            this.btn_j.Text = "j";
            this.btn_j.UseVisualStyleBackColor = true;
            this.btn_j.Click += new System.EventHandler(this.btn_j_Click);
            // 
            // btn_h
            // 
            this.btn_h.Location = new System.Drawing.Point(270, 459);
            this.btn_h.Name = "btn_h";
            this.btn_h.Size = new System.Drawing.Size(32, 23);
            this.btn_h.TabIndex = 19;
            this.btn_h.Text = "h";
            this.btn_h.UseVisualStyleBackColor = true;
            this.btn_h.Click += new System.EventHandler(this.btn_h_Click);
            // 
            // btn_g
            // 
            this.btn_g.Location = new System.Drawing.Point(232, 459);
            this.btn_g.Name = "btn_g";
            this.btn_g.Size = new System.Drawing.Size(32, 23);
            this.btn_g.TabIndex = 18;
            this.btn_g.Text = "g";
            this.btn_g.UseVisualStyleBackColor = true;
            this.btn_g.Click += new System.EventHandler(this.btn_g_Click);
            // 
            // btn_f
            // 
            this.btn_f.Location = new System.Drawing.Point(194, 459);
            this.btn_f.Name = "btn_f";
            this.btn_f.Size = new System.Drawing.Size(32, 23);
            this.btn_f.TabIndex = 17;
            this.btn_f.Text = "f";
            this.btn_f.UseVisualStyleBackColor = true;
            this.btn_f.Click += new System.EventHandler(this.btn_f_Click);
            // 
            // btn_d
            // 
            this.btn_d.Location = new System.Drawing.Point(156, 459);
            this.btn_d.Name = "btn_d";
            this.btn_d.Size = new System.Drawing.Size(32, 23);
            this.btn_d.TabIndex = 16;
            this.btn_d.Text = "d";
            this.btn_d.UseVisualStyleBackColor = true;
            this.btn_d.Click += new System.EventHandler(this.btn_d_Click);
            // 
            // btn_s
            // 
            this.btn_s.Location = new System.Drawing.Point(118, 459);
            this.btn_s.Name = "btn_s";
            this.btn_s.Size = new System.Drawing.Size(32, 23);
            this.btn_s.TabIndex = 15;
            this.btn_s.Text = "s";
            this.btn_s.UseVisualStyleBackColor = true;
            this.btn_s.Click += new System.EventHandler(this.btn_s_Click);
            // 
            // btn_a
            // 
            this.btn_a.Location = new System.Drawing.Point(80, 459);
            this.btn_a.Name = "btn_a";
            this.btn_a.Size = new System.Drawing.Size(32, 23);
            this.btn_a.TabIndex = 14;
            this.btn_a.Text = "a";
            this.btn_a.UseVisualStyleBackColor = true;
            this.btn_a.Click += new System.EventHandler(this.btn_a_Click);
            // 
            // btn_rovnase
            // 
            this.btn_rovnase.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_rovnase.Location = new System.Drawing.Point(473, 401);
            this.btn_rovnase.Name = "btn_rovnase";
            this.btn_rovnase.Size = new System.Drawing.Size(32, 23);
            this.btn_rovnase.TabIndex = 37;
            this.btn_rovnase.Text = "=";
            this.btn_rovnase.UseVisualStyleBackColor = false;
            this.btn_rovnase.Click += new System.EventHandler(this.btn_rovnase_click);
            // 
            // btn_minus
            // 
            this.btn_minus.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_minus.Location = new System.Drawing.Point(435, 401);
            this.btn_minus.Name = "btn_minus";
            this.btn_minus.Size = new System.Drawing.Size(32, 23);
            this.btn_minus.TabIndex = 36;
            this.btn_minus.Text = "-";
            this.btn_minus.UseVisualStyleBackColor = false;
            this.btn_minus.Click += new System.EventHandler(this.btn_minus_click);
            // 
            // btn_0
            // 
            this.btn_0.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_0.Location = new System.Drawing.Point(397, 401);
            this.btn_0.Name = "btn_0";
            this.btn_0.Size = new System.Drawing.Size(32, 23);
            this.btn_0.TabIndex = 35;
            this.btn_0.Text = "0";
            this.btn_0.UseVisualStyleBackColor = false;
            this.btn_0.Click += new System.EventHandler(this.btn_0_click);
            // 
            // btn_9
            // 
            this.btn_9.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_9.Location = new System.Drawing.Point(359, 401);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(32, 23);
            this.btn_9.TabIndex = 34;
            this.btn_9.Text = "9";
            this.btn_9.UseVisualStyleBackColor = false;
            this.btn_9.Click += new System.EventHandler(this.btn_9_click);
            // 
            // btn_8
            // 
            this.btn_8.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_8.Location = new System.Drawing.Point(321, 401);
            this.btn_8.Name = "btn_8";
            this.btn_8.Size = new System.Drawing.Size(32, 23);
            this.btn_8.TabIndex = 33;
            this.btn_8.Text = "8";
            this.btn_8.UseVisualStyleBackColor = false;
            this.btn_8.Click += new System.EventHandler(this.btn_8_click);
            // 
            // btn_7
            // 
            this.btn_7.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_7.Location = new System.Drawing.Point(283, 401);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(32, 23);
            this.btn_7.TabIndex = 32;
            this.btn_7.Text = "7";
            this.btn_7.UseVisualStyleBackColor = false;
            this.btn_7.Click += new System.EventHandler(this.btn_7_click);
            // 
            // btn_6
            // 
            this.btn_6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_6.Location = new System.Drawing.Point(245, 401);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(32, 23);
            this.btn_6.TabIndex = 31;
            this.btn_6.Text = "6";
            this.btn_6.UseVisualStyleBackColor = false;
            this.btn_6.Click += new System.EventHandler(this.btn_6_click);
            // 
            // btn_5
            // 
            this.btn_5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_5.Location = new System.Drawing.Point(207, 401);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(32, 23);
            this.btn_5.TabIndex = 30;
            this.btn_5.Text = "5";
            this.btn_5.UseVisualStyleBackColor = false;
            this.btn_5.Click += new System.EventHandler(this.btn_5_click);
            // 
            // btn_4
            // 
            this.btn_4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_4.Location = new System.Drawing.Point(169, 401);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(32, 23);
            this.btn_4.TabIndex = 29;
            this.btn_4.Text = "4";
            this.btn_4.UseVisualStyleBackColor = false;
            this.btn_4.Click += new System.EventHandler(this.btn_4_click);
            // 
            // btn_3
            // 
            this.btn_3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_3.Location = new System.Drawing.Point(131, 401);
            this.btn_3.Name = "btn_3";
            this.btn_3.Size = new System.Drawing.Size(32, 23);
            this.btn_3.TabIndex = 28;
            this.btn_3.Text = "3";
            this.btn_3.UseVisualStyleBackColor = false;
            this.btn_3.Click += new System.EventHandler(this.btn_3_click);
            // 
            // btn_2
            // 
            this.btn_2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_2.Location = new System.Drawing.Point(93, 401);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(32, 23);
            this.btn_2.TabIndex = 27;
            this.btn_2.Text = "2";
            this.btn_2.UseVisualStyleBackColor = false;
            this.btn_2.Click += new System.EventHandler(this.btn_2_click);
            // 
            // btn_1
            // 
            this.btn_1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_1.Location = new System.Drawing.Point(55, 401);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(32, 23);
            this.btn_1.TabIndex = 26;
            this.btn_1.Text = "1";
            this.btn_1.UseVisualStyleBackColor = false;
            this.btn_1.Click += new System.EventHandler(this.btn_1_click);
            // 
            // btn_strednik
            // 
            this.btn_strednik.Location = new System.Drawing.Point(12, 401);
            this.btn_strednik.Name = "btn_strednik";
            this.btn_strednik.Size = new System.Drawing.Size(39, 23);
            this.btn_strednik.TabIndex = 38;
            this.btn_strednik.Text = ";";
            this.btn_strednik.UseVisualStyleBackColor = true;
            this.btn_strednik.Click += new System.EventHandler(this.btn_strednik_click);
            // 
            // btn_tab
            // 
            this.btn_tab.Location = new System.Drawing.Point(12, 430);
            this.btn_tab.Name = "btn_tab";
            this.btn_tab.Size = new System.Drawing.Size(48, 23);
            this.btn_tab.TabIndex = 39;
            this.btn_tab.Text = "Tab";
            this.btn_tab.UseVisualStyleBackColor = true;
            this.btn_tab.Click += new System.EventHandler(this.btn_tab_Click);
            // 
            // btn_shift_0
            // 
            this.btn_shift_0.Location = new System.Drawing.Point(12, 459);
            this.btn_shift_0.Name = "btn_shift_0";
            this.btn_shift_0.Size = new System.Drawing.Size(62, 23);
            this.btn_shift_0.TabIndex = 40;
            this.btn_shift_0.Text = "Shift";
            this.btn_shift_0.UseVisualStyleBackColor = true;
            this.btn_shift_0.Click += new System.EventHandler(this.btn_shift_Click);
            // 
            // btn_capslock
            // 
            this.btn_capslock.Location = new System.Drawing.Point(12, 488);
            this.btn_capslock.Name = "btn_capslock";
            this.btn_capslock.Size = new System.Drawing.Size(75, 23);
            this.btn_capslock.TabIndex = 53;
            this.btn_capslock.Text = "CapsLock";
            this.btn_capslock.UseVisualStyleBackColor = true;
            this.btn_capslock.Click += new System.EventHandler(this.btn_capslock_Click);
            // 
            // btn_shift_1
            // 
            this.btn_shift_1.Location = new System.Drawing.Point(473, 488);
            this.btn_shift_1.Name = "btn_shift_1";
            this.btn_shift_1.Size = new System.Drawing.Size(115, 23);
            this.btn_shift_1.TabIndex = 52;
            this.btn_shift_1.Text = "Shift";
            this.btn_shift_1.UseVisualStyleBackColor = true;
            this.btn_shift_1.Click += new System.EventHandler(this.btn_shift_Click);
            // 
            // btn_zv_7
            // 
            this.btn_zv_7.Location = new System.Drawing.Point(435, 488);
            this.btn_zv_7.Name = "btn_zv_7";
            this.btn_zv_7.Size = new System.Drawing.Size(32, 23);
            this.btn_zv_7.TabIndex = 50;
            this.btn_zv_7.Text = "-";
            this.btn_zv_7.UseVisualStyleBackColor = true;
            this.btn_zv_7.Click += new System.EventHandler(this.btn_zv_7_Click);
            // 
            // btn_zv_6
            // 
            this.btn_zv_6.Location = new System.Drawing.Point(397, 488);
            this.btn_zv_6.Name = "btn_zv_6";
            this.btn_zv_6.Size = new System.Drawing.Size(32, 23);
            this.btn_zv_6.TabIndex = 49;
            this.btn_zv_6.Text = ".";
            this.btn_zv_6.UseVisualStyleBackColor = true;
            this.btn_zv_6.Click += new System.EventHandler(this.btn_zv_6_Click);
            // 
            // btn_zv_5
            // 
            this.btn_zv_5.Location = new System.Drawing.Point(359, 488);
            this.btn_zv_5.Name = "btn_zv_5";
            this.btn_zv_5.Size = new System.Drawing.Size(32, 23);
            this.btn_zv_5.TabIndex = 48;
            this.btn_zv_5.Text = ",";
            this.btn_zv_5.UseVisualStyleBackColor = true;
            this.btn_zv_5.Click += new System.EventHandler(this.btn_zv_5_Click);
            // 
            // btn_m
            // 
            this.btn_m.Location = new System.Drawing.Point(321, 488);
            this.btn_m.Name = "btn_m";
            this.btn_m.Size = new System.Drawing.Size(32, 23);
            this.btn_m.TabIndex = 47;
            this.btn_m.Text = "m";
            this.btn_m.UseVisualStyleBackColor = true;
            this.btn_m.Click += new System.EventHandler(this.btn_m_Click);
            // 
            // btn_n
            // 
            this.btn_n.Location = new System.Drawing.Point(283, 488);
            this.btn_n.Name = "btn_n";
            this.btn_n.Size = new System.Drawing.Size(32, 23);
            this.btn_n.TabIndex = 46;
            this.btn_n.Text = "n";
            this.btn_n.UseVisualStyleBackColor = true;
            this.btn_n.Click += new System.EventHandler(this.btn_n_Click);
            // 
            // btn_b
            // 
            this.btn_b.Location = new System.Drawing.Point(245, 488);
            this.btn_b.Name = "btn_b";
            this.btn_b.Size = new System.Drawing.Size(32, 23);
            this.btn_b.TabIndex = 45;
            this.btn_b.Text = "b";
            this.btn_b.UseVisualStyleBackColor = true;
            this.btn_b.Click += new System.EventHandler(this.btn_b_Click);
            // 
            // btn_v
            // 
            this.btn_v.Location = new System.Drawing.Point(207, 488);
            this.btn_v.Name = "btn_v";
            this.btn_v.Size = new System.Drawing.Size(32, 23);
            this.btn_v.TabIndex = 44;
            this.btn_v.Text = "v";
            this.btn_v.UseVisualStyleBackColor = true;
            this.btn_v.Click += new System.EventHandler(this.btn_v_Click);
            // 
            // btn_c
            // 
            this.btn_c.Location = new System.Drawing.Point(169, 488);
            this.btn_c.Name = "btn_c";
            this.btn_c.Size = new System.Drawing.Size(32, 23);
            this.btn_c.TabIndex = 43;
            this.btn_c.Text = "c";
            this.btn_c.UseVisualStyleBackColor = true;
            this.btn_c.Click += new System.EventHandler(this.btn_c_Click);
            // 
            // btn_x
            // 
            this.btn_x.Location = new System.Drawing.Point(131, 488);
            this.btn_x.Name = "btn_x";
            this.btn_x.Size = new System.Drawing.Size(32, 23);
            this.btn_x.TabIndex = 42;
            this.btn_x.Text = "x";
            this.btn_x.UseVisualStyleBackColor = true;
            this.btn_x.Click += new System.EventHandler(this.btn_x_Click);
            // 
            // btn_y
            // 
            this.btn_y.Location = new System.Drawing.Point(93, 488);
            this.btn_y.Name = "btn_y";
            this.btn_y.Size = new System.Drawing.Size(32, 23);
            this.btn_y.TabIndex = 41;
            this.btn_y.Text = "z";
            this.btn_y.UseVisualStyleBackColor = true;
            this.btn_y.Click += new System.EventHandler(this.btn_y_z_Click);
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(536, 430);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(52, 52);
            this.button42.TabIndex = 54;
            this.button42.Text = "Enter";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.btn_enter);
            // 
            // btn_zpet
            // 
            this.btn_zpet.Location = new System.Drawing.Point(511, 401);
            this.btn_zpet.Name = "btn_zpet";
            this.btn_zpet.Size = new System.Drawing.Size(77, 23);
            this.btn_zpet.TabIndex = 55;
            this.btn_zpet.Text = "BackSpace";
            this.btn_zpet.UseVisualStyleBackColor = true;
            this.btn_zpet.Click += new System.EventHandler(this.btn_zpet_click);
            // 
            // btn_reset_0
            // 
            this.btn_reset_0.Location = new System.Drawing.Point(12, 517);
            this.btn_reset_0.Name = "btn_reset_0";
            this.btn_reset_0.Size = new System.Drawing.Size(39, 23);
            this.btn_reset_0.TabIndex = 56;
            this.btn_reset_0.Text = "RES";
            this.btn_reset_0.UseVisualStyleBackColor = true;
            this.btn_reset_0.Click += new System.EventHandler(this.btn_res_click);
            // 
            // btn_eng_0
            // 
            this.btn_eng_0.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eng_0.Location = new System.Drawing.Point(57, 517);
            this.btn_eng_0.Name = "btn_eng_0";
            this.btn_eng_0.Size = new System.Drawing.Size(41, 23);
            this.btn_eng_0.TabIndex = 57;
            this.btn_eng_0.Text = "CZ";
            this.btn_eng_0.UseVisualStyleBackColor = false;
            this.btn_eng_0.Click += new System.EventHandler(this.btn_eng_cz_click);
            // 
            // btn_alt_0
            // 
            this.btn_alt_0.Location = new System.Drawing.Point(104, 517);
            this.btn_alt_0.Name = "btn_alt_0";
            this.btn_alt_0.Size = new System.Drawing.Size(39, 23);
            this.btn_alt_0.TabIndex = 58;
            this.btn_alt_0.Text = "Alt";
            this.btn_alt_0.UseVisualStyleBackColor = true;
            this.btn_alt_0.Click += new System.EventHandler(this.btn_alt_0_Click);
            // 
            // btn_mezernik
            // 
            this.btn_mezernik.Location = new System.Drawing.Point(149, 517);
            this.btn_mezernik.Name = "btn_mezernik";
            this.btn_mezernik.Size = new System.Drawing.Size(255, 23);
            this.btn_mezernik.TabIndex = 59;
            this.btn_mezernik.Text = "Space";
            this.btn_mezernik.UseVisualStyleBackColor = true;
            this.btn_mezernik.Click += new System.EventHandler(this.btn_mezernik_Click);
            // 
            // btn_alt_1
            // 
            this.btn_alt_1.Location = new System.Drawing.Point(410, 517);
            this.btn_alt_1.Name = "btn_alt_1";
            this.btn_alt_1.Size = new System.Drawing.Size(39, 23);
            this.btn_alt_1.TabIndex = 60;
            this.btn_alt_1.Text = "Alt";
            this.btn_alt_1.UseVisualStyleBackColor = true;
            this.btn_alt_1.Click += new System.EventHandler(this.btn_alt_0_Click);
            // 
            // btn_eng_1
            // 
            this.btn_eng_1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eng_1.Location = new System.Drawing.Point(455, 517);
            this.btn_eng_1.Name = "btn_eng_1";
            this.btn_eng_1.Size = new System.Drawing.Size(41, 23);
            this.btn_eng_1.TabIndex = 61;
            this.btn_eng_1.Text = "CZ";
            this.btn_eng_1.UseVisualStyleBackColor = false;
            this.btn_eng_1.Click += new System.EventHandler(this.btn_eng_cz_click);
            // 
            // btn_reset_1
            // 
            this.btn_reset_1.Location = new System.Drawing.Point(549, 517);
            this.btn_reset_1.Name = "btn_reset_1";
            this.btn_reset_1.Size = new System.Drawing.Size(39, 23);
            this.btn_reset_1.TabIndex = 62;
            this.btn_reset_1.Text = "RES";
            this.btn_reset_1.UseVisualStyleBackColor = true;
            this.btn_reset_1.Click += new System.EventHandler(this.btn_res_click);
            // 
            // btn_win_lock
            // 
            this.btn_win_lock.Location = new System.Drawing.Point(502, 517);
            this.btn_win_lock.Name = "btn_win_lock";
            this.btn_win_lock.Size = new System.Drawing.Size(41, 23);
            this.btn_win_lock.TabIndex = 63;
            this.btn_win_lock.Text = "Fn";
            this.btn_win_lock.UseVisualStyleBackColor = true;
            this.btn_win_lock.Click += new System.EventHandler(this.btn_win_lock_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.SystemColors.Control;
            this.checkBox1.Enabled = false;
            this.checkBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.checkBox1.Location = new System.Drawing.Point(607, 388);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(48, 17);
            this.checkBox1.TabIndex = 68;
            this.checkBox1.Text = "Num";
            this.checkBox1.UseVisualStyleBackColor = false;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Enabled = false;
            this.checkBox2.Location = new System.Drawing.Point(661, 388);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(50, 17);
            this.checkBox2.TabIndex = 69;
            this.checkBox2.Text = "Caps";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Enabled = false;
            this.checkBox3.Location = new System.Drawing.Point(717, 388);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(45, 17);
            this.checkBox3.TabIndex = 70;
            this.checkBox3.Text = "Win";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // btn_num
            // 
            this.btn_num.Location = new System.Drawing.Point(607, 411);
            this.btn_num.Name = "btn_num";
            this.btn_num.Size = new System.Drawing.Size(44, 23);
            this.btn_num.TabIndex = 71;
            this.btn_num.Text = "Num";
            this.btn_num.UseVisualStyleBackColor = true;
            this.btn_num.Click += new System.EventHandler(this.btn_num_Click);
            // 
            // btn_num_deleno
            // 
            this.btn_num_deleno.Location = new System.Drawing.Point(657, 411);
            this.btn_num_deleno.Name = "btn_num_deleno";
            this.btn_num_deleno.Size = new System.Drawing.Size(44, 23);
            this.btn_num_deleno.TabIndex = 72;
            this.btn_num_deleno.Text = "/";
            this.btn_num_deleno.UseVisualStyleBackColor = true;
            this.btn_num_deleno.Click += new System.EventHandler(this.btn_num_deleno_Click);
            // 
            // bnt_num_krat
            // 
            this.bnt_num_krat.Location = new System.Drawing.Point(707, 411);
            this.bnt_num_krat.Name = "bnt_num_krat";
            this.bnt_num_krat.Size = new System.Drawing.Size(44, 23);
            this.bnt_num_krat.TabIndex = 73;
            this.bnt_num_krat.Text = "*";
            this.bnt_num_krat.UseVisualStyleBackColor = true;
            this.bnt_num_krat.Click += new System.EventHandler(this.bnt_num_krat_Click);
            // 
            // btn_num_minus
            // 
            this.btn_num_minus.Location = new System.Drawing.Point(757, 411);
            this.btn_num_minus.Name = "btn_num_minus";
            this.btn_num_minus.Size = new System.Drawing.Size(44, 23);
            this.btn_num_minus.TabIndex = 74;
            this.btn_num_minus.Text = "-";
            this.btn_num_minus.UseVisualStyleBackColor = true;
            this.btn_num_minus.Click += new System.EventHandler(this.btn_num_minus_Click);
            // 
            // btn_num_plus
            // 
            this.btn_num_plus.Location = new System.Drawing.Point(757, 440);
            this.btn_num_plus.Name = "btn_num_plus";
            this.btn_num_plus.Size = new System.Drawing.Size(44, 52);
            this.btn_num_plus.TabIndex = 75;
            this.btn_num_plus.Text = "+";
            this.btn_num_plus.UseVisualStyleBackColor = true;
            this.btn_num_plus.Click += new System.EventHandler(this.btn_num_plus_Click);
            // 
            // btn_num_9
            // 
            this.btn_num_9.Enabled = false;
            this.btn_num_9.Location = new System.Drawing.Point(707, 440);
            this.btn_num_9.Name = "btn_num_9";
            this.btn_num_9.Size = new System.Drawing.Size(44, 23);
            this.btn_num_9.TabIndex = 76;
            this.btn_num_9.Text = "9";
            this.btn_num_9.UseVisualStyleBackColor = true;
            this.btn_num_9.Click += new System.EventHandler(this.btn_num_9_Click);
            // 
            // btn_num_8
            // 
            this.btn_num_8.Enabled = false;
            this.btn_num_8.Location = new System.Drawing.Point(657, 440);
            this.btn_num_8.Name = "btn_num_8";
            this.btn_num_8.Size = new System.Drawing.Size(44, 23);
            this.btn_num_8.TabIndex = 77;
            this.btn_num_8.Text = "8";
            this.btn_num_8.UseVisualStyleBackColor = true;
            this.btn_num_8.Click += new System.EventHandler(this.btn_num_8_Click);
            // 
            // btn_num_7
            // 
            this.btn_num_7.Enabled = false;
            this.btn_num_7.Location = new System.Drawing.Point(607, 440);
            this.btn_num_7.Name = "btn_num_7";
            this.btn_num_7.Size = new System.Drawing.Size(44, 23);
            this.btn_num_7.TabIndex = 78;
            this.btn_num_7.Text = "7";
            this.btn_num_7.UseVisualStyleBackColor = true;
            this.btn_num_7.Click += new System.EventHandler(this.btn_num_7_Click);
            // 
            // btn_num_6
            // 
            this.btn_num_6.Enabled = false;
            this.btn_num_6.Location = new System.Drawing.Point(707, 469);
            this.btn_num_6.Name = "btn_num_6";
            this.btn_num_6.Size = new System.Drawing.Size(44, 23);
            this.btn_num_6.TabIndex = 79;
            this.btn_num_6.Text = "6";
            this.btn_num_6.UseVisualStyleBackColor = true;
            this.btn_num_6.Click += new System.EventHandler(this.btn_num_6_Click);
            // 
            // btn_num_3
            // 
            this.btn_num_3.Enabled = false;
            this.btn_num_3.Location = new System.Drawing.Point(707, 498);
            this.btn_num_3.Name = "btn_num_3";
            this.btn_num_3.Size = new System.Drawing.Size(44, 23);
            this.btn_num_3.TabIndex = 80;
            this.btn_num_3.Text = "3";
            this.btn_num_3.UseVisualStyleBackColor = true;
            this.btn_num_3.Click += new System.EventHandler(this.btn_num_3_Click);
            // 
            // btn_num_carka
            // 
            this.btn_num_carka.Enabled = false;
            this.btn_num_carka.Location = new System.Drawing.Point(707, 527);
            this.btn_num_carka.Name = "btn_num_carka";
            this.btn_num_carka.Size = new System.Drawing.Size(44, 23);
            this.btn_num_carka.TabIndex = 81;
            this.btn_num_carka.Text = ",";
            this.btn_num_carka.UseVisualStyleBackColor = true;
            this.btn_num_carka.Click += new System.EventHandler(this.btn_num_carka_Click);
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(757, 498);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(44, 52);
            this.button73.TabIndex = 82;
            this.button73.Text = "Ent";
            this.button73.UseVisualStyleBackColor = true;
            this.button73.Click += new System.EventHandler(this.btn_enter);
            // 
            // btn_num_5
            // 
            this.btn_num_5.Enabled = false;
            this.btn_num_5.Location = new System.Drawing.Point(657, 469);
            this.btn_num_5.Name = "btn_num_5";
            this.btn_num_5.Size = new System.Drawing.Size(44, 23);
            this.btn_num_5.TabIndex = 83;
            this.btn_num_5.Text = "5";
            this.btn_num_5.UseVisualStyleBackColor = true;
            this.btn_num_5.Click += new System.EventHandler(this.btn_num_5_Click);
            // 
            // btn_num_2
            // 
            this.btn_num_2.Enabled = false;
            this.btn_num_2.Location = new System.Drawing.Point(657, 498);
            this.btn_num_2.Name = "btn_num_2";
            this.btn_num_2.Size = new System.Drawing.Size(44, 23);
            this.btn_num_2.TabIndex = 84;
            this.btn_num_2.Text = "2";
            this.btn_num_2.UseVisualStyleBackColor = true;
            this.btn_num_2.Click += new System.EventHandler(this.btn_num_2_Click);
            // 
            // btn_num_4
            // 
            this.btn_num_4.Enabled = false;
            this.btn_num_4.Location = new System.Drawing.Point(607, 469);
            this.btn_num_4.Name = "btn_num_4";
            this.btn_num_4.Size = new System.Drawing.Size(44, 23);
            this.btn_num_4.TabIndex = 86;
            this.btn_num_4.Text = "4";
            this.btn_num_4.UseVisualStyleBackColor = true;
            this.btn_num_4.Click += new System.EventHandler(this.btn_num_4_Click);
            // 
            // btn_num_1
            // 
            this.btn_num_1.Enabled = false;
            this.btn_num_1.Location = new System.Drawing.Point(607, 498);
            this.btn_num_1.Name = "btn_num_1";
            this.btn_num_1.Size = new System.Drawing.Size(44, 23);
            this.btn_num_1.TabIndex = 87;
            this.btn_num_1.Text = "1";
            this.btn_num_1.UseVisualStyleBackColor = true;
            this.btn_num_1.Click += new System.EventHandler(this.btn_num_1_Click);
            // 
            // btn_num_0
            // 
            this.btn_num_0.Enabled = false;
            this.btn_num_0.Location = new System.Drawing.Point(607, 527);
            this.btn_num_0.Name = "btn_num_0";
            this.btn_num_0.Size = new System.Drawing.Size(94, 23);
            this.btn_num_0.TabIndex = 88;
            this.btn_num_0.Text = "0";
            this.btn_num_0.UseVisualStyleBackColor = true;
            this.btn_num_0.Click += new System.EventHandler(this.btn_num_0_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 385);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 90;
            this.label1.Text = "Aktuální: ENG";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(848, 668);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_num_0);
            this.Controls.Add(this.btn_num_1);
            this.Controls.Add(this.btn_num_4);
            this.Controls.Add(this.btn_num_2);
            this.Controls.Add(this.btn_num_5);
            this.Controls.Add(this.button73);
            this.Controls.Add(this.btn_num_carka);
            this.Controls.Add(this.btn_num_3);
            this.Controls.Add(this.btn_num_6);
            this.Controls.Add(this.btn_num_7);
            this.Controls.Add(this.btn_num_8);
            this.Controls.Add(this.btn_num_9);
            this.Controls.Add(this.btn_num_plus);
            this.Controls.Add(this.btn_num_minus);
            this.Controls.Add(this.bnt_num_krat);
            this.Controls.Add(this.btn_num_deleno);
            this.Controls.Add(this.btn_num);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.btn_win_lock);
            this.Controls.Add(this.btn_reset_1);
            this.Controls.Add(this.btn_eng_1);
            this.Controls.Add(this.btn_alt_1);
            this.Controls.Add(this.btn_mezernik);
            this.Controls.Add(this.btn_alt_0);
            this.Controls.Add(this.btn_eng_0);
            this.Controls.Add(this.btn_reset_0);
            this.Controls.Add(this.btn_zpet);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.btn_capslock);
            this.Controls.Add(this.btn_shift_1);
            this.Controls.Add(this.btn_zv_7);
            this.Controls.Add(this.btn_zv_6);
            this.Controls.Add(this.btn_zv_5);
            this.Controls.Add(this.btn_m);
            this.Controls.Add(this.btn_n);
            this.Controls.Add(this.btn_b);
            this.Controls.Add(this.btn_v);
            this.Controls.Add(this.btn_c);
            this.Controls.Add(this.btn_x);
            this.Controls.Add(this.btn_y);
            this.Controls.Add(this.btn_shift_0);
            this.Controls.Add(this.btn_tab);
            this.Controls.Add(this.btn_strednik);
            this.Controls.Add(this.btn_rovnase);
            this.Controls.Add(this.btn_minus);
            this.Controls.Add(this.btn_0);
            this.Controls.Add(this.btn_9);
            this.Controls.Add(this.btn_8);
            this.Controls.Add(this.btn_7);
            this.Controls.Add(this.btn_6);
            this.Controls.Add(this.btn_5);
            this.Controls.Add(this.btn_4);
            this.Controls.Add(this.btn_3);
            this.Controls.Add(this.btn_2);
            this.Controls.Add(this.btn_1);
            this.Controls.Add(this.btn_zv_4);
            this.Controls.Add(this.btn_zv_3);
            this.Controls.Add(this.btn_zv_2);
            this.Controls.Add(this.btn_l);
            this.Controls.Add(this.btn_k);
            this.Controls.Add(this.btn_j);
            this.Controls.Add(this.btn_h);
            this.Controls.Add(this.btn_g);
            this.Controls.Add(this.btn_f);
            this.Controls.Add(this.btn_d);
            this.Controls.Add(this.btn_s);
            this.Controls.Add(this.btn_a);
            this.Controls.Add(this.btn_zv_1);
            this.Controls.Add(this.btn_zv_0);
            this.Controls.Add(this.btn_p);
            this.Controls.Add(this.btn_o);
            this.Controls.Add(this.btn_i);
            this.Controls.Add(this.btn_u);
            this.Controls.Add(this.btn_z);
            this.Controls.Add(this.btn_t);
            this.Controls.Add(this.btn_r);
            this.Controls.Add(this.btn_e);
            this.Controls.Add(this.btn_w);
            this.Controls.Add(this.btn_q);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Soubor);
            this.MainMenuStrip = this.Soubor;
            this.Name = "Form1";
            this.Text = "Textak";
            this.Soubor.ResumeLayout(false);
            this.Soubor.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.MenuStrip Soubor;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem otevřítToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otevřítToolStripMenuItem1;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem barvaToolStripMenuItem;
        private System.Windows.Forms.Button btn_q;
        private System.Windows.Forms.Button btn_w;
        private System.Windows.Forms.Button btn_e;
        private System.Windows.Forms.Button btn_r;
        private System.Windows.Forms.Button btn_t;
        private System.Windows.Forms.Button btn_z;
        private System.Windows.Forms.Button btn_zv_1;
        private System.Windows.Forms.Button btn_zv_0;
        private System.Windows.Forms.Button btn_p;
        private System.Windows.Forms.Button btn_o;
        private System.Windows.Forms.Button btn_i;
        private System.Windows.Forms.Button btn_u;
        private System.Windows.Forms.Button btn_zv_4;
        private System.Windows.Forms.Button btn_zv_3;
        private System.Windows.Forms.Button btn_zv_2;
        private System.Windows.Forms.Button btn_l;
        private System.Windows.Forms.Button btn_k;
        private System.Windows.Forms.Button btn_j;
        private System.Windows.Forms.Button btn_h;
        private System.Windows.Forms.Button btn_g;
        private System.Windows.Forms.Button btn_f;
        private System.Windows.Forms.Button btn_d;
        private System.Windows.Forms.Button btn_s;
        private System.Windows.Forms.Button btn_a;
        private System.Windows.Forms.Button btn_rovnase;
        private System.Windows.Forms.Button btn_minus;
        private System.Windows.Forms.Button btn_0;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Button btn_8;
        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.Button btn_3;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Button btn_strednik;
        private System.Windows.Forms.Button btn_tab;
        private System.Windows.Forms.Button btn_shift_0;
        private System.Windows.Forms.Button btn_capslock;
        private System.Windows.Forms.Button btn_shift_1;
        private System.Windows.Forms.Button btn_zv_7;
        private System.Windows.Forms.Button btn_zv_6;
        private System.Windows.Forms.Button btn_zv_5;
        private System.Windows.Forms.Button btn_m;
        private System.Windows.Forms.Button btn_n;
        private System.Windows.Forms.Button btn_b;
        private System.Windows.Forms.Button btn_v;
        private System.Windows.Forms.Button btn_c;
        private System.Windows.Forms.Button btn_x;
        private System.Windows.Forms.Button btn_y;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button btn_zpet;
        private System.Windows.Forms.Button btn_reset_0;
        private System.Windows.Forms.Button btn_eng_0;
        private System.Windows.Forms.Button btn_alt_0;
        private System.Windows.Forms.Button btn_mezernik;
        private System.Windows.Forms.Button btn_alt_1;
        private System.Windows.Forms.Button btn_eng_1;
        private System.Windows.Forms.Button btn_reset_1;
        private System.Windows.Forms.Button btn_win_lock;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Button btn_num;
        private System.Windows.Forms.Button btn_num_deleno;
        private System.Windows.Forms.Button bnt_num_krat;
        private System.Windows.Forms.Button btn_num_minus;
        private System.Windows.Forms.Button btn_num_plus;
        private System.Windows.Forms.Button btn_num_9;
        private System.Windows.Forms.Button btn_num_8;
        private System.Windows.Forms.Button btn_num_7;
        private System.Windows.Forms.Button btn_num_6;
        private System.Windows.Forms.Button btn_num_3;
        private System.Windows.Forms.Button btn_num_carka;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button btn_num_5;
        private System.Windows.Forms.Button btn_num_2;
        private System.Windows.Forms.Button btn_num_4;
        private System.Windows.Forms.Button btn_num_1;
        private System.Windows.Forms.Button btn_num_0;
        private System.Windows.Forms.Label label1;
    }
}

